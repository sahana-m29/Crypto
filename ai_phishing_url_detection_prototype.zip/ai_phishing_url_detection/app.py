"""Streamlit UI for the URL-feature phishing detection prototype."""
from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import urlsplit

import joblib
import pandas as pd
import streamlit as st

from url_features import FEATURE_NAMES, extract_url_features, normalize_url

MODEL_PATH = Path("models/phishing_url_model.joblib")
METADATA_PATH = Path("models/model_metadata.json")

st.set_page_config(
    page_title="Phishing URL Detector",
    page_icon="🛡️",
    layout="centered",
)

st.title("🛡️ AI-Based Phishing Website Detection")
st.caption("URL-feature machine-learning prototype · Crypto / Cybersecurity project")

st.info(
    "This prototype analyzes the URL string only. It does not visit or open the website. "
    "Predictions can be wrong and must not be treated as a guarantee of safety."
)

if not MODEL_PATH.exists():
    st.warning("No trained model was found yet.")
    st.markdown(
        "### First train the model\n"
        "Open the project terminal and run:\n\n"
        "`python train_model.py --csv dataset/demo_urls.csv --url-column url --label-column label --phishing-label phishing`\n\n"
        "Then restart or refresh this page."
    )
    st.stop()

bundle = joblib.load(MODEL_PATH)
model = bundle["model"]
feature_names = bundle.get("feature_names", FEATURE_NAMES)

with st.form("url_check_form"):
    url_input = st.text_input(
        "Website URL",
        placeholder="https://example.com/login",
        help="Enter a URL. The app will not open it.",
    )
    submitted = st.form_submit_button("Analyze URL", type="primary", use_container_width=True)

if submitted:
    if not url_input.strip():
        st.error("Please enter a URL first.")
        st.stop()

    normalized = normalize_url(url_input)
    parts = urlsplit(normalized)
    if not parts.hostname or "." not in parts.hostname and parts.hostname.lower() != "localhost":
        st.error("Please enter a valid-looking hostname, such as example.com.")
        st.stop()

    features = extract_url_features(url_input)
    row = pd.DataFrame([[features.get(name, 0.0) for name in feature_names]], columns=feature_names)
    prediction = int(model.predict(row)[0])
    probabilities = model.predict_proba(row)[0] if hasattr(model, "predict_proba") else None

    st.subheader("Analysis result")
    if prediction == 1:
        st.error("⚠️ Model prediction: POTENTIALLY PHISHING")
    else:
        st.success("Model prediction: LIKELY LEGITIMATE")

    if probabilities is not None:
        class_index = list(model.classes_).index(prediction)
        confidence = float(probabilities[class_index]) * 100
        st.metric("Model confidence for this class", f"{confidence:.1f}%")
        st.caption("This is the model's confidence score, not a calibrated probability that the site is safe or malicious.")

    st.write("**URL analyzed:**")
    st.code(url_input.strip(), language=None)

    st.subheader("URL feature inspection")
    feature_df = pd.DataFrame(
        [{"Feature": name.replace("_", " ").title(), "Value": value} for name, value in features.items()]
    )
    st.dataframe(feature_df, use_container_width=True, hide_index=True)

    flagged = []
    if features["has_ip_address"]:
        flagged.append("The hostname is an IP address.")
    if features["count_at_symbols"]:
        flagged.append("The URL contains an @ symbol.")
    if features["has_punycode"]:
        flagged.append("The hostname contains punycode.")
    if features["has_url_shortener_domain"]:
        flagged.append("The hostname is a known URL-shortening domain.")
    if features["count_suspicious_words"]:
        flagged.append("One or more security/account-related keywords appear in the URL.")
    if features["has_https"] == 0:
        flagged.append("The URL does not use HTTPS; this alone does not prove phishing.")
    if features["subdomain_count"] >= 3:
        flagged.append("The hostname contains several subdomain labels.")

    st.subheader("Indicators to review")
    if flagged:
        for item in flagged:
            st.write(f"- {item}")
    else:
        st.write("No simple heuristic indicators from this list were detected. That does not establish that the URL is safe.")

    st.warning(
        "Do not enter passwords, payment details, or sensitive information on a site based only on this result. "
        "When uncertain, navigate to the organization's official website directly."
    )

with st.expander("About this prototype"):
    st.write(
        "The Random Forest model is trained on labeled URL examples and a fixed set of lexical features. "
        "Performance depends on dataset quality and how well training URLs represent future URLs. "
        "The app does not fetch pages, inspect certificates, or query live reputation services."
    )
    if METADATA_PATH.exists():
        try:
            metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
            st.write("Training dataset rows:", metadata.get("n_rows", "Unknown"))
            st.write("Model:", metadata.get("model", "Unknown"))
            st.write("Features used:", len(metadata.get("features", [])))
        except Exception:
            pass

"""URL-only feature extraction for phishing detection.

This module never opens or fetches the submitted URL. Features are based only
on the string entered by the user.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit, unquote

SUSPICIOUS_WORDS = (
    "login", "verify", "verification", "account", "secure", "update",
    "signin", "sign-in", "password", "banking", "wallet", "payment",
    "confirm", "authenticate", "recover", "support", "billing", "webscr",
)

FEATURE_NAMES = [
    "url_length",
    "hostname_length",
    "path_length",
    "query_length",
    "count_dots",
    "count_hyphens",
    "count_underscores",
    "count_slashes",
    "count_question_marks",
    "count_equals",
    "count_at_symbols",
    "count_ampersands",
    "count_percent",
    "count_digits",
    "digit_ratio",
    "has_https",
    "has_http",
    "has_ip_address",
    "hostname_has_hyphen",
    "subdomain_count",
    "count_suspicious_words",
    "has_url_shortener_domain",
    "has_nonstandard_port",
    "has_punycode",
    "path_has_file_extension",
    "query_present",
    "fragment_present",
]

SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly",
    "is.gd", "buff.ly", "rebrand.ly", "cutt.ly", "rb.gy",
}

def normalize_url(raw_url: str) -> str:
    """Trim whitespace and add a parsing scheme when the user omitted it."""
    value = str(raw_url).strip()
    if not value:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
        value = "http://" + value
    return value

def _is_ip(hostname: str) -> int:
    try:
        ipaddress.ip_address(hostname.strip("[]"))
        return 1
    except ValueError:
        return 0

def extract_url_features(raw_url: str) -> dict[str, float]:
    """Return a fixed, ordered set of numeric URL features."""
    url = normalize_url(raw_url)
    parts = urlsplit(url)
    host = (parts.hostname or "").lower().rstrip(".")
    path = unquote(parts.path or "")
    query = parts.query or ""
    full_lower = url.lower()
    digits = sum(ch.isdigit() for ch in url)
    suspicious_count = sum(1 for word in SUSPICIOUS_WORDS if word in full_lower)

    try:
        port = parts.port
    except ValueError:
        port = None

    try:
        host_labels = [x for x in host.split(".") if x]
        subdomain_count = max(0, len(host_labels) - 2) if not _is_ip(host) else 0
    except Exception:
        subdomain_count = 0

    extension_match = re.search(r"\.[a-zA-Z0-9]{1,8}$", path)
    shortener = int(host in SHORTENER_DOMAINS)

    return {
        "url_length": float(len(url)),
        "hostname_length": float(len(host)),
        "path_length": float(len(path)),
        "query_length": float(len(query)),
        "count_dots": float(url.count(".")),
        "count_hyphens": float(url.count("-")),
        "count_underscores": float(url.count("_")),
        "count_slashes": float(url.count("/")),
        "count_question_marks": float(url.count("?")),
        "count_equals": float(url.count("=")),
        "count_at_symbols": float(url.count("@")),
        "count_ampersands": float(url.count("&")),
        "count_percent": float(url.count("%")),
        "count_digits": float(digits),
        "digit_ratio": float(digits / max(1, len(url))),
        "has_https": float(parts.scheme.lower() == "https"),
        "has_http": float(parts.scheme.lower() == "http"),
        "has_ip_address": float(_is_ip(host)),
        "hostname_has_hyphen": float("-" in host),
        "subdomain_count": float(subdomain_count),
        "count_suspicious_words": float(suspicious_count),
        "has_url_shortener_domain": float(shortener),
        "has_nonstandard_port": float(port is not None and port not in (80, 443)),
        "has_punycode": float("xn--" in host),
        "path_has_file_extension": float(bool(extension_match)),
        "query_present": float(bool(query)),
        "fragment_present": float(bool(parts.fragment)),
    }

def extract_feature_row(raw_url: str, feature_names: list[str] | None = None) -> list[float]:
    """Return values in the requested model feature order."""
    features = extract_url_features(raw_url)
    names = feature_names or FEATURE_NAMES
    return [float(features.get(name, 0.0)) for name in names]

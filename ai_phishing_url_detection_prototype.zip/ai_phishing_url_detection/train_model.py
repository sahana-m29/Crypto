"""Train a URL-only phishing classifier from a labeled CSV."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score,
)
from sklearn.model_selection import train_test_split

from url_features import FEATURE_NAMES, extract_url_features

MODEL_DIR = Path("models")
MODEL_PATH = MODEL_DIR / "phishing_url_model.joblib"
METADATA_PATH = MODEL_DIR / "model_metadata.json"

URL_COLUMN_CANDIDATES = ["url", "URL", "domain", "Domain", "website", "Website", "uri", "URI"]
LABEL_COLUMN_CANDIDATES = ["label", "Label", "class", "Class", "status", "Status", "result", "Result", "phishing"]

def find_column(columns, requested, candidates, role):
    if requested:
        if requested not in columns:
            raise ValueError(f"{role} column {requested!r} not found. Available columns: {list(columns)}")
        return requested
    lower_map = {str(c).strip().lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]
    raise ValueError(
        f"Could not automatically identify the {role} column. "
        f"Available columns: {list(columns)}. Pass --{role}-column COLUMN_NAME."
    )

def normalize_label(value):
    if pd.isna(value):
        return None
    if isinstance(value, str):
        s = value.strip().lower()
        mapping = {
            "phishing": 1, "phish": 1, "malicious": 1, "malware": 1,
            "bad": 1, "1": 1, "true": 1, "yes": 1,
            "legitimate": 0, "legit": 0, "benign": 0, "safe": 0,
            "good": 0, "0": 0, "false": 0, "no": 0,
        }
        if s in mapping:
            return mapping[s]
        try:
            return int(float(s))
        except ValueError:
            return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None

def main():
    parser = argparse.ArgumentParser(description="Train a phishing detector using URL-string features only.")
    parser.add_argument("--csv", default="dataset/demo_urls.csv", help="Path to labeled CSV dataset")
    parser.add_argument("--url-column", default=None, help="Column containing the raw URL")
    parser.add_argument("--label-column", default=None, help="Column containing the class label")
    parser.add_argument("--phishing-label", default=None, help="Original label value meaning phishing (e.g. 1 or phishing)")
    parser.add_argument("--test-size", type=float, default=0.2, help="Test fraction, default 0.2")
    parser.add_argument("--random-state", type=int, default=42)
    args = parser.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        print(f"ERROR: CSV not found: {csv_path}", file=sys.stderr)
        sys.exit(1)

    df = pd.read_csv(csv_path)
    if df.empty:
        raise SystemExit("ERROR: Dataset is empty.")
    url_col = find_column(df.columns, args.url_column, URL_COLUMN_CANDIDATES, "url")
    label_col = find_column(df.columns, args.label_column, LABEL_COLUMN_CANDIDATES, "label")

    working = df[[url_col, label_col]].copy()
    working.columns = ["url", "original_label"]
    working = working.dropna(subset=["url", "original_label"])
    working["url"] = working["url"].astype(str).str.strip()
    working = working[working["url"] != ""]
    if working.empty:
        raise SystemExit("ERROR: No rows with both URL and label.")

    if args.phishing_label is not None:
        phish_value = args.phishing_label.strip().lower()
        working["target"] = working["original_label"].map(
            lambda x: 1 if str(x).strip().lower() == phish_value else 0
        )
    else:
        working["target"] = working["original_label"].map(normalize_label)

    working = working.dropna(subset=["target"])
    working["target"] = working["target"].astype(int)
    unique_targets = sorted(working["target"].unique().tolist())
    if len(unique_targets) != 2:
        raise SystemExit(
            f"ERROR: Expected exactly two classes after label mapping, found {unique_targets}. "
            "Inspect labels and pass --phishing-label if needed."
        )
    if not set(unique_targets).issubset({0, 1}):
        raise SystemExit("ERROR: Labels must map to 0=legitimate and 1=phishing.")

    # Keep one occurrence per URL to reduce duplicate leakage across train/test.
    working["url_key"] = working["url"].str.lower().str.strip()
    working = working.drop_duplicates("url_key").drop(columns=["url_key"])
    if working["target"].value_counts().min() < 2:
        raise SystemExit("ERROR: Need at least two unique examples in each class.")

    print(f"Rows used: {len(working):,}")
    print("Class counts (0=legitimate, 1=phishing):")
    print(working["target"].value_counts().sort_index().to_string())

    print("\nExtracting URL features...")
    features = pd.DataFrame(
        [extract_url_features(url) for url in working["url"]],
        columns=FEATURE_NAMES,
    )
    X_train, X_test, y_train, y_test = train_test_split(
        features, working["target"], test_size=args.test_size,
        random_state=args.random_state, stratify=working["target"],
    )

    model = RandomForestClassifier(
        n_estimators=250,
        max_depth=None,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=args.random_state,
        n_jobs=-1,
    )
    print("\nTraining Random Forest...")
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    print("\n=== Evaluation on held-out test split ===")
    print(f"Accuracy : {accuracy_score(y_test, preds):.4f}")
    print(f"Precision: {precision_score(y_test, preds, zero_division=0):.4f}")
    print(f"Recall   : {recall_score(y_test, preds, zero_division=0):.4f}")
    print(f"F1-score : {f1_score(y_test, preds, zero_division=0):.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, preds, target_names=["Legitimate (0)", "Phishing (1)"], zero_division=0))
    print("Confusion matrix (rows=true labels, columns=predicted labels):")
    print(confusion_matrix(y_test, preds).tolist())
    try:
        probs = model.predict_proba(X_test)[:, list(model.classes_).index(1)]
        print(f"ROC-AUC  : {roc_auc_score(y_test, probs):.4f}")
    except Exception:
        print("ROC-AUC  : unavailable")

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "feature_names": FEATURE_NAMES}, MODEL_PATH)
    metadata = {
        "url_column": str(url_col),
        "label_column": str(label_col),
        "label_mapping": "0=legitimate, 1=phishing",
        "n_rows": int(len(working)),
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "features": FEATURE_NAMES,
        "model": "RandomForestClassifier",
        "warning": "Metrics depend on dataset quality and split; URL-only model is not a safety guarantee."
    }
    METADATA_PATH.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"\nSaved model: {MODEL_PATH}")
    print(f"Saved metadata: {METADATA_PATH}")
    print("\nNext: streamlit run app.py")

if __name__ == "__main__":
    main()

# AI-Based Phishing Website Detection Using URL Features

A student-friendly working prototype that trains a machine-learning classifier on labeled URLs and provides a Streamlit interface for checking a URL.

## Features
- Extracts lexical URL features without opening the submitted URL.
- Trains a Random Forest model using a labeled CSV dataset.
- Supports common dataset layouts with a URL column and a label column.
- Saves the trained model and feature names under `models/`.
- Displays prediction, model probability (not a guarantee of safety), and feature indicators.
- Includes a small synthetic starter dataset so the full workflow can be tested immediately.
- Includes evaluation metrics and a confusion matrix report.

## Requirements
- Python 3.10+ recommended
- Windows, macOS, or Linux
- Internet is not required to run the app after dependencies and dataset are installed.

## Quick start (Windows / VS Code)

1. Extract this ZIP.
2. Open the extracted `ai_phishing_url_detection` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create and activate a virtual environment:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt and run:
```bat
venv\Scripts\activate.bat
```

5. Install dependencies:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

6. Add a real dataset:
   - Download a labeled phishing URL CSV, for example from UCI's PhiUSIIL dataset page:
     https://archive.ics.uci.edu/dataset/967/phiusiil+phishing+url+dataset
   - Put the CSV in `dataset/`.
   - Review its column names and label mapping before training.
   - Use `--url-column` and `--label-column` to select the columns.
   - For this project, the model deliberately trains on URL-derived features only, not precomputed page-content or post-visit features.

7. Train the model:

```bash
python train_model.py --csv dataset/your_dataset.csv --url-column URL --label-column label
```

Replace `URL` and `label` with actual column names. Labels can be strings like `phishing` / `legitimate`, or numeric labels; numeric label mapping is explained below.

For datasets where `1` means phishing and `0` means legitimate (or vice versa), explicitly set the positive label:

```bash
python train_model.py --csv dataset/your_dataset.csv --url-column URL --label-column label --phishing-label 1
```

If labels are numeric and `--phishing-label` is omitted, the script assumes the largest numeric label is phishing. Verify this assumption before using the model.

8. Launch the app:

```bash
streamlit run app.py
```

Streamlit opens the prototype in your browser, usually at `http://localhost:8501`.

## Test immediately with starter dataset

The ZIP contains `dataset/demo_urls.csv`, a small synthetic dataset for testing that the code runs end-to-end. It is **not** a suitable dataset for claiming real-world accuracy and is not representative of live phishing. To test the whole workflow:

```bash
python train_model.py --csv dataset/demo_urls.csv --url-column url --label-column label --phishing-label phishing
streamlit run app.py
```

For meaningful project results, train on a larger, verified, real labeled dataset and report test metrics. Do not present demo dataset scores as real-world performance.

## Label conventions
- If labels are text, the script recognizes common values such as `phishing`, `malicious`, `bad`, `legitimate`, `benign`, `good`, and `safe`.
- If labels are numeric, set `--phishing-label` to the numeric value representing phishing.
- Always inspect your dataset's label meanings before training.

## Files
- `url_features.py` — URL-only feature extraction.
- `train_model.py` — dataset loading, feature extraction, model training, evaluation, and model saving.
- `app.py` — Streamlit interface.
- `requirements.txt` — Python dependencies.
- `dataset/demo_urls.csv` — synthetic smoke-test data only.
- `models/` — generated model artifacts are saved here after training.

## Limitations and safety
- URL-only ML is a heuristic, not a guarantee. Legitimate URLs can look suspicious and phishing URLs can look ordinary.
- HTTPS alone does not mean a website is safe.
- The prototype does not open, visit, or fetch the submitted URL.
- The displayed probability is the model's class probability, not a calibrated real-world risk probability.
- Do not use this prototype as the only protection for financial, institutional, or production systems.
